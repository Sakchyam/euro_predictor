from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# Load the trained model
model = joblib.load('football_prediction_model.pkl')

# Define a function to predict match outcome
def predict_outcome(features):
    # Example: features = [goals_scored, goals_conceded, possession, ...]
    prediction = model.predict([features])
    return prediction[0]

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle form submission and display prediction
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Example: Extract features from form input
        goals_scored = float(request.form['goals_scored'])
        goals_conceded = float(request.form['goals_conceded'])
        possession = float(request.form['possession'])
        # Add more features as needed

        # Make prediction
        features = [goals_scored, goals_conceded, possession]
        prediction = predict_outcome(features)

        # Convert prediction to meaningful result
        if prediction == 1:
            result = "England wins"
        elif prediction == -1:
            result = "Netherlands wins"
        else:
            result = "Draw"

        return render_template('result.html', result=result)
